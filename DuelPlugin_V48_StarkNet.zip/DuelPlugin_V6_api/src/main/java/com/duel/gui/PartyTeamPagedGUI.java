package com.duel.gui;

import com.duel.DuelPlugin;
import com.duel.party.Party;
import com.duel.utils.SoundUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

/**
 * GUI التيمات للبارتيات الكبيرة (أكثر من 30 لاعب) — بصفحات.
 *
 *  صف 0-4 (خانات 0-44) : راس كل عضو (45 في الصفحة) — كليك = ينقله بين الأزرق والأحمر
 *  صف 5 (الأسفل)        : التحكم
 *     45 سهم السابق | 47 عدّاد الأزرق | 48 راس القائد = Random | 49 Save
 *     50 عدّاد الأحمر | 51 رقم الصفحة | 53 سهم التالي
 */
public class PartyTeamPagedGUI implements InventoryHolder {

    public static final int SIZE        = 54;
    public static final int PER_PAGE    = 45;
    public static final int PREV_SLOT   = 45;
    public static final int BLUE_SLOT   = 47;
    public static final int RANDOM_SLOT = 48;
    public static final int SAVE_SLOT   = 49;
    public static final int RED_SLOT    = 50;
    public static final int PAGE_SLOT   = 51;
    public static final int NEXT_SLOT   = 53;

    private final DuelPlugin plugin;
    private final Party party;
    private final Inventory inventory;

    /** كل أعضاء البارتي (القائد أول واحد) — ترتيب ثابت عشان الصفحات ما تقفز */
    private final List<UUID> members = new ArrayList<>();
    /** true = الأزرق، false = الأحمر */
    private final Map<UUID, Boolean> blue = new HashMap<>();
    private int page = 0;

    /** لو انفتح من Team في PartyModeGUI: الأرينا اللي تبدأ فيها المباراة بعد Save */
    private com.duel.models.Arena pendingArena = null;

    private PartyTeamPagedGUI(DuelPlugin plugin, Party party) {
        this.plugin = plugin;
        this.party = party;
        this.inventory = Bukkit.createInventory(this, SIZE,
                Component.text("⚔ Party Teams (" + party.getSize() + " players)").color(NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.BOLD, false));
        loadInitialArrangement();
        render();
    }

    // ─────────────────────────────────────────
    //  فتح (يُستدعى من PartyTeamGUI.open بعد التشيكات)
    // ─────────────────────────────────────────

    static void open(DuelPlugin plugin, Player player, Party party, com.duel.models.Arena arena) {
        SoundUtils.playGuiClick(player);
        PartyTeamPagedGUI gui = new PartyTeamPagedGUI(plugin, party);
        gui.pendingArena = arena;
        player.openInventory(gui.getInventory());
    }

    private void loadInitialArrangement() {
        members.addAll(party.getMembers());
        members.remove(party.getLeader().getUniqueId());
        members.add(0, party.getLeader().getUniqueId());

        int blueCount = 0, redCount = 0;
        if (party.hasTeams()) {
            for (UUID u : members) {
                if (party.getTeamTop().contains(u))         { blue.put(u, true);  blueCount++; }
                else if (party.getTeamBottom().contains(u)) { blue.put(u, false); redCount++; }
            }
            // أي عضو جديد غير موزّع → التيم الأصغر
            for (UUID u : members) {
                if (blue.containsKey(u)) continue;
                boolean toBlue = blueCount <= redCount;
                blue.put(u, toBlue);
                if (toBlue) blueCount++; else redCount++;
            }
        } else {
            int half = (members.size() + 1) / 2;
            for (int i = 0; i < members.size(); i++) blue.put(members.get(i), i < half);
        }
    }

    // ─────────────────────────────────────────
    //  Render
    // ─────────────────────────────────────────

    private int pages() { return Math.max(1, (members.size() + PER_PAGE - 1) / PER_PAGE); }

    private int count(boolean isBlue) {
        int c = 0;
        for (UUID u : members) if (blue.get(u) == isBlue) c++;
        return c;
    }

    private void render() {
        inventory.clear();

        ItemStack glass = simple(Material.GRAY_STAINED_GLASS_PANE, " ", NamedTextColor.GRAY);
        for (int i = PER_PAGE; i < SIZE; i++) inventory.setItem(i, glass);

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = start + i;
            if (idx >= members.size()) break;
            inventory.setItem(i, memberItem(members.get(idx)));
        }

        if (page > 0) inventory.setItem(PREV_SLOT, simple(Material.ARROW, "Previous Page", NamedTextColor.YELLOW,
                "Page " + page + "/" + pages()));
        if (page < pages() - 1) inventory.setItem(NEXT_SLOT, simple(Material.ARROW, "Next Page", NamedTextColor.YELLOW,
                "Page " + (page + 2) + "/" + pages()));

        inventory.setItem(BLUE_SLOT, simple(Material.BLUE_WOOL, "Blue Team: " + count(true), NamedTextColor.BLUE));
        inventory.setItem(RED_SLOT,  simple(Material.RED_WOOL,  "Red Team: " + count(false), NamedTextColor.RED));
        inventory.setItem(PAGE_SLOT, simple(Material.PAPER, "Page " + (page + 1) + "/" + pages(), NamedTextColor.WHITE,
                "Click a player to switch his team"));
        inventory.setItem(RANDOM_SLOT, randomItem());
        inventory.setItem(SAVE_SLOT, simple(Material.EMERALD_BLOCK, "Save", NamedTextColor.GREEN,
                "Click to save the teams",
                "§9Blue: §f" + count(true) + "  §cRed: §f" + count(false),
                "§8Min " + PartyTeamGUI.MIN_TEAM + " players per team"));
    }

    private ItemStack memberItem(UUID u) {
        boolean isBlue = blue.getOrDefault(u, true);
        OfflinePlayer op = Bukkit.getOfflinePlayer(u);
        String name = op.getName() != null ? op.getName() : "Unknown";

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(op);
        meta.displayName(Component.text(name).color(isBlue ? NamedTextColor.BLUE : NamedTextColor.RED)
                .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(line(isBlue ? "§9▌ Blue Team" : "§c▌ Red Team"));
        lore.add(line("§7Click to move to the " + (isBlue ? "§cRed" : "§9Blue") + " §7team"));
        if (u.equals(party.getLeader().getUniqueId())) lore.add(line("§6★ Party leader"));
        meta.lore(lore);
        head.setItemMeta(meta);
        return head;
    }

    private ItemStack randomItem() {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(party.getLeader());
        meta.displayName(Component.text("Random Teams").color(NamedTextColor.GOLD)
                .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(line("§7Click to split the party randomly"), line("§7into two even teams")));
        head.setItemMeta(meta);
        return head;
    }

    private static Component line(String legacy) {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection()
                .deserialize(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack simple(Material mat, String name, NamedTextColor color, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).color(color)
                .decoration(TextDecoration.BOLD, mat != Material.GRAY_STAINED_GLASS_PANE)
                .decoration(TextDecoration.ITALIC, false));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(line(s.startsWith("§") ? s : "§7" + s));
            meta.lore(l);
        }
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    // ─────────────────────────────────────────
    //  Click
    // ─────────────────────────────────────────

    public void handleClick(Player player, int slot) {
        // لازم يبقى قائد نفس البارتي (نفس تحقق PartyTeamGUI)
        if (!party.getLeader().equals(player) || plugin.getPartyManager().getParty(player) != party) {
            player.closeInventory();
            return;
        }
        if (slot < 0 || slot >= SIZE) return;

        if (slot < PER_PAGE) {
            int idx = page * PER_PAGE + slot;
            if (idx >= members.size()) return;
            UUID u = members.get(idx);
            blue.put(u, !blue.getOrDefault(u, true));
            SoundUtils.playGuiClick(player);
            render();
            return;
        }

        switch (slot) {
            case PREV_SLOT -> { if (page > 0) { page--; SoundUtils.playGuiClick(player); render(); } }
            case NEXT_SLOT -> { if (page < pages() - 1) { page++; SoundUtils.playGuiClick(player); render(); } }
            case RANDOM_SLOT -> randomize(player);
            case SAVE_SLOT -> save(player);
            default -> { }
        }
    }

    private void randomize(Player leader) {
        List<UUID> shuffled = new ArrayList<>(members);
        Collections.shuffle(shuffled);
        int half = (shuffled.size() + 1) / 2;
        for (int i = 0; i < shuffled.size(); i++) blue.put(shuffled.get(i), i < half);
        SoundUtils.playGuiClick(leader);
        render();
    }

    private void save(Player leader) {
        // البارتي تغيّر وانت فاتح الـ GUI؟
        if (!new HashSet<>(party.getMembers()).equals(new HashSet<>(members))) {
            leader.closeInventory();
            leader.sendMessage("§c[Party] The party members changed. Choose §eTeam §cagain from Party FFA.");
            return;
        }
        if (members.size() > PartyTeamGUI.MAX_PARTY) {
            leader.sendMessage("§c[Party] Teams support at most " + PartyTeamGUI.MAX_PARTY + " players.");
            return;
        }

        List<UUID> top = new ArrayList<>();
        List<UUID> bottom = new ArrayList<>();
        for (UUID u : members) {
            if (blue.getOrDefault(u, true)) top.add(u); else bottom.add(u);
        }
        if (top.size() < PartyTeamGUI.MIN_TEAM || bottom.size() < PartyTeamGUI.MIN_TEAM) {
            leader.sendMessage("§c[Party] Each team needs at least " + PartyTeamGUI.MIN_TEAM + " player.");
            return;
        }

        party.setTeams(top, bottom);
        leader.closeInventory();
        SoundUtils.playSave(leader);

        party.broadcastAll("§6[Party] §aTeams saved: §9Blue (" + top.size() + ") §7vs §cRed (" + bottom.size() + ")§a."
                + (pendingArena == null ? " §7The leader can start the match with Party FFA." : ""));
        for (UUID u : top)    { Player p = Bukkit.getPlayer(u); if (p != null) p.sendMessage("§6[Party] §7You are on the §9Blue Team§7."); }
        for (UUID u : bottom) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendMessage("§6[Party] §7You are on the §cRed Team§7."); }

        if (pendingArena != null) {
            plugin.getPartyDuelManager().startPartyTeams(party, pendingArena);
        }
    }

    /** يُستدعى لما عضو ينقطع اتصاله والـ GUI مفتوح — ينشاله من الترتيب بدل ما يخرب الـ Save */
    public void syncMembers() {
        Set<UUID> current = new HashSet<>(party.getMembers());
        if (members.removeIf(u -> !current.contains(u))) {
            blue.keySet().retainAll(current);
            if (page >= pages()) page = pages() - 1;
            render();
        }
    }

    @Override
    public Inventory getInventory() { return inventory; }
}
