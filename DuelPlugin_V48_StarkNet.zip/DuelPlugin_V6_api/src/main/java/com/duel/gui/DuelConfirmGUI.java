package com.duel.gui;

import com.duel.DuelPlugin;
import com.duel.managers.CountryManager;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Confirmation screen shown to the sender AFTER choosing the arena and
 * BEFORE the request is sent to the opponent.
 *
 *   Row 1 :  . . . . [Opponent head] . . . .
 *   Row 2 :  . [Cancel] . [Flag] [Arena] [Clock] . [Continue] .
 *   Everything else is gray glass.
 */
public class DuelConfirmGUI implements InventoryHolder {

    public static final int SIZE         = 45;
    public static final int SLOT_HEAD    = 13;
    public static final int SLOT_CANCEL  = 19;
    public static final int SLOT_FLAG    = 21;
    public static final int SLOT_ARENA   = 22;
    public static final int SLOT_CLOCK   = 23;
    public static final int SLOT_CONFIRM = 25;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH);

    private final DuelPlugin plugin;
    private final Player     sender;
    private final Player     target;
    private final Arena      arena;
    private final Inventory  inventory;

    public DuelConfirmGUI(DuelPlugin plugin, Player sender, Player target, Arena arena) {
        this.plugin = plugin;
        this.sender = sender;
        this.target = target;
        this.arena  = arena;
        this.inventory = Bukkit.createInventory(this, SIZE, Component.text("Duel " + target.getName()));
        populate();
    }

    // ─────────────────────────────────────────
    //  Layout
    // ─────────────────────────────────────────

    private void populate() {
        ItemStack filler = ItemUtils.buildFiller(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < SIZE; i++) inventory.setItem(i, filler);

        inventory.setItem(SLOT_HEAD,    buildHead());
        inventory.setItem(SLOT_ARENA,   buildArena());
        inventory.setItem(SLOT_FLAG,    buildFlag());
        inventory.setItem(SLOT_CLOCK,   buildClock());
        inventory.setItem(SLOT_CANCEL,  buildCancel());
        inventory.setItem(SLOT_CONFIRM, buildConfirm());
    }

    private ItemStack buildHead() {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(target.getUniqueId()));
        meta.displayName(Component.text("Opponent")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(target.getName())
                .color(NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildArena() {
        ItemStack item;
        List<ItemStack> guiItems = arena.getGuiItems();
        if (!guiItems.isEmpty()) item = guiItems.get(0).clone();
        else item = new ItemStack(Material.GRASS_BLOCK);

        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Arena")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(arena.getId())
                .color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Opponent's country flag. Rendered by the resource pack (custom model on a
     * paper item). Players without the pack just see a named paper item; unknown
     * / unsupported countries get a plain white banner.
     */
    private ItemStack buildFlag() {
        CountryManager cm = plugin.getCountryManager();
        String code = cm.getCountryCode(target.getUniqueId());
        String countryName = CountryManager.getCountryName(code);
        int modelData = CountryManager.toFlagModelData(code);

        ItemStack item;
        if (modelData >= 0) {
            item = new ItemStack(Material.PAPER);
            ItemMeta m = item.getItemMeta();
            m.setCustomModelData(modelData);
            item.setItemMeta(m);
        } else {
            item = new ItemStack(Material.WHITE_BANNER);
        }

        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Country")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(countryName)
                .color(NamedTextColor.WHITE)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /** Local time + date at the opponent's location (GeoIP timezone). */
    private ItemStack buildClock() {
        ZoneId zone = plugin.getCountryManager().getZoneId(target.getUniqueId());
        boolean known = zone != null;
        if (!known) zone = ZoneId.systemDefault();
        ZonedDateTime now = ZonedDateTime.now(zone);

        ItemStack item = new ItemStack(Material.CLOCK);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Local Time")
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(line("──────────────", NamedTextColor.DARK_GRAY));
        lore.add(Component.text("Time  ").color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(now.format(TIME_FMT)).color(NamedTextColor.YELLOW)
                        .decoration(TextDecoration.BOLD, true).decoration(TextDecoration.ITALIC, false)));
        lore.add(Component.text("Date  ").color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(now.format(DATE_FMT)).color(NamedTextColor.WHITE)
                        .decoration(TextDecoration.ITALIC, false)));
        lore.add(line("──────────────", NamedTextColor.DARK_GRAY));
        lore.add(Component.text(known ? zone.getId().replace('_', ' ') : "Timezone unavailable (server time)")
                .color(NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, true));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildConfirm() {
        ItemStack item = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Continue")
                .color(NamedTextColor.GREEN)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(line("Click to send the duel request", NamedTextColor.GRAY));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildCancel() {
        ItemStack item = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Cancel")
                .color(NamedTextColor.RED)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(line("Click to cancel the challenge", NamedTextColor.GRAY));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text).color(color).decoration(TextDecoration.ITALIC, false);
    }

    // ─────────────────────────────────────────
    //  API
    // ─────────────────────────────────────────

    public static void open(DuelPlugin plugin, Player sender, Player target, Arena arena) {
        DuelConfirmGUI gui = new DuelConfirmGUI(plugin, sender, target, arena);
        sender.openInventory(gui.getInventory());
    }

    public Player getSender() { return sender; }
    public Player getTarget() { return target; }
    public Arena  getArena()  { return arena; }

    @Override
    public Inventory getInventory() { return inventory; }
}
