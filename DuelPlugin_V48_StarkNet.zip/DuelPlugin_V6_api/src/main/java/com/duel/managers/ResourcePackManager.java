package com.duel.managers;

import com.duel.DuelPlugin;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.bukkit.entity.Player;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.MessageDigest;

/**
 * Serves the bundled flags resource pack (src/main/resources/resourcepack/flags-pack.zip)
 * over a tiny built-in HTTP server, and sends it to players automatically on join —
 * no external hosting needed.
 *
 * Config (config.yml):
 *   resource-pack.enabled:         true/false — master switch
 *   resource-pack.port:            local port to bind the HTTP server to
 *   resource-pack.public-address:  the address/domain players' clients can reach
 *                                  this server on (e.g. "play.example.com" or a
 *                                  public IP). REQUIRED — the plugin cannot safely
 *                                  auto-detect this behind NAT/firewalls/proxies.
 *   resource-pack.prompt-message:  message shown in the client's pack-download prompt
 *
 * IMPORTANT: the configured port must be open/forwarded on your firewall/router
 * separately from the Minecraft server port, or players' clients won't be able
 * to reach it to download the pack.
 */
public class ResourcePackManager {

    private final DuelPlugin plugin;
    private HttpServer server;
    private byte[] packBytes;
    private String packSha1;

    public ResourcePackManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (!plugin.getConfig().getBoolean("resource-pack.enabled", false)) return;

        try {
            packBytes = loadBundledPack();
            packSha1 = sha1Hex(packBytes);
        } catch (Exception e) {
            plugin.getLogger().severe("[ResourcePackManager] Failed to load bundled flags-pack.zip: " + e.getMessage());
            return;
        }

        int port = plugin.getConfig().getInt("resource-pack.port", 25566);
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext("/flags-pack.zip", this::handleRequest);
            server.setExecutor(null); // default executor is fine for a small static file
            server.start();
            plugin.getLogger().info("[ResourcePackManager] Serving flags resource pack on port " + port);
        } catch (Exception e) {
            plugin.getLogger().severe("[ResourcePackManager] Failed to start HTTP server on port " + port
                    + " — is it already in use? " + e.getMessage());
        }
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
    }

    private void handleRequest(HttpExchange exchange) throws java.io.IOException {
        exchange.getResponseHeaders().add("Content-Type", "application/zip");
        exchange.sendResponseHeaders(200, packBytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(packBytes);
        }
    }

    /** Sends the pack to a player. Call this on join (after a short delay is safest). */
    public void sendToPlayer(Player player) {
        if (server == null || packBytes == null) return; // feature disabled or failed to start

        String publicAddress = plugin.getConfig().getString("resource-pack.public-address", "");
        if (publicAddress == null || publicAddress.isBlank()) {
            plugin.getLogger().warning("[ResourcePackManager] resource-pack.public-address is not set in config.yml"
                    + " — cannot send the pack to players. Set it to your server's public IP or domain.");
            return;
        }

        int port = plugin.getConfig().getInt("resource-pack.port", 25566);
        String url = "http://" + publicAddress + ":" + port + "/flags-pack.zip";
        String prompt = plugin.getConfig().getString("resource-pack.prompt-message",
                "&aDuelPlugin country flags — optional, purely cosmetic.");

        player.setResourcePack(url, java.util.HexFormat.of().parseHex(packSha1),
            net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection()
                .deserialize(org.bukkit.ChatColor.translateAlternateColorCodes('&', prompt)), false);
    }

    private byte[] loadBundledPack() throws Exception {
        try (InputStream in = plugin.getResource("resourcepack/flags-pack.zip")) {
            if (in == null) throw new IllegalStateException("resourcepack/flags-pack.zip not found in jar");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private String sha1Hex(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] hash = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
