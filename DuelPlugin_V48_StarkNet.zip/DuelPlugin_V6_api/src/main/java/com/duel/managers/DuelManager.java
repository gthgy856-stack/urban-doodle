package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.models.DuelSession;
import com.duel.models.Kit;
import com.duel.trim.TrimManager;
import com.duel.utils.SoundUtils;
import com.duel.utils.TitleUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class DuelManager {

    private final DuelPlugin plugin;
    // sessionId → session
    private final Map<UUID, DuelSession> sessions = new HashMap<>();
    // player UUID → session
    private final Map<UUID, DuelSession> playerSession = new HashMap<>();
    /** لاعبين بدأ لهم دول لكن العالم لسا ما جهز — يحسبون "في دول" */
    private final Set<UUID> pendingStart = new HashSet<>();

    public DuelManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────
    //  Start a duel between two players
    // ─────────────────────────────────────────

    public void startDuel(Player p1, Player p2, Arena arena) {
        String templateWorld = arena.getRandomWorld();
        if (templateWorld == null) {
            p1.sendMessage(color("&cNo worlds configured for this arena!"));
            p2.sendMessage(color("&cNo worlds configured for this arena!"));
            return;
        }

        // حماية مركزية: اللاعب اللي في بارتي ما يدخل دول 1v1 (ريماتش/كيو/دعوات/أي مسار)
        if (plugin.getPartyManager().isInParty(p1) || plugin.getPartyManager().isInParty(p2)) {
            p1.sendMessage(color("&c⚔ You can't duel while in a party."));
            p2.sendMessage(color("&c⚔ You can't duel while in a party."));
            for (Player p : new Player[]{p1, p2}) {
                if (plugin.getQueueManager().isQueued(p)) plugin.getQueueManager().removeFromQueue(p);
                plugin.getDuelRequestManager().cancelAllFor(p);
            }
            return;
        }

        if (isBusy(p1) || isBusy(p2)) return; // حماية من بدء دولين لنفس اللاعب (الجلسات المنتهية لا تُحسب — مهم للريماتش)

        // نظّف أي انتظار/دعوات متبقية للاعبين
        for (Player p : new Player[]{p1, p2}) {
            if (plugin.getQueueManager().isQueued(p)) plugin.getQueueManager().removeFromQueue(p);
            plugin.getDuelRequestManager().cancelAllFor(p);
            pendingStart.add(p.getUniqueId());
        }

        String copyName = plugin.getConfig().getString("settings.arena-copy-prefix", "duel_arena_")
                + arena.getId() + "_" + System.currentTimeMillis();

        // Notify players
        p1.sendMessage(color("&a⚔ Match found! Preparing arena..."));
        p2.sendMessage(color("&a⚔ Match found! Preparing arena..."));

        // Lock movement immediately
        p1.setWalkSpeed(0f);
        p2.setWalkSpeed(0f);
        p1.setFlySpeed(0f);
        p2.setFlySpeed(0f);

        // Clone world async (Multiverse handles this), then schedule duel setup
        final String finalTemplateWorld = templateWorld;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            final String worldName = plugin.getWorldPoolManager().acquire(finalTemplateWorld, copyName);
            waitForWorld(worldName, () -> onWorldReady(p1, p2, arena, finalTemplateWorld, worldName),
                    () -> { abortStart(p1, p2); });
        });
    }

    /** يرجّع الحركة الطبيعية للاعب (آمن لو كان offline) */
    private void unfreeze(Player p) {
        try {
            if (p != null && p.isOnline()) {
                p.setWalkSpeed(0.2f);
                p.setFlySpeed(0.1f);
                p.setInvulnerable(false);
            }
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] unfreeze failed", t);
        }
    }

    /** اللاعب مشغول لو عنده جلسة نشطة (غير ENDED) أو بدء دول قيد التجهيز */
    private boolean isBusy(Player p) {
        if (pendingStart.contains(p.getUniqueId())) return true;
        DuelSession s = playerSession.get(p.getUniqueId());
        return s != null && s.getState() != DuelSession.State.ENDED;
    }

    /** فشل تجهيز العالم — نفك التجميد ونشيل حالة الانتظار حتى ما يعلق اللاعبين */
    private void abortStart(Player p1, Player p2) {
        for (Player p : new Player[]{p1, p2}) {
            pendingStart.remove(p.getUniqueId());
            if (p.isOnline()) {
                p.setWalkSpeed(0.2f);
                p.setFlySpeed(0.1f);
                p.setInvulnerable(false);
                p.sendMessage(color("&c⚔ Failed to prepare the arena. Please try again."));
            }
        }
    }

    /** Poll every 10 ticks until the world is loaded, then run callback */
    private void waitForWorld(String worldName, Runnable callback, Runnable onTimeout) {
        if (Bukkit.getWorld(worldName) != null) {
            callback.run();
            return;
        }
        final int[] attempts = {0};
        plugin.getServer().getScheduler().runTaskTimer(plugin, task -> {
            attempts[0]++;
            World w = Bukkit.getWorld(worldName);
            if (w != null) {
                task.cancel();
                callback.run();
            } else if (plugin.getArenaManager().isCopyFailed(worldName) || attempts[0] > 200) { // 50s timeout
                task.cancel();
                plugin.getLogger().warning("World copy timed out: " + worldName);
                onTimeout.run();
            }
        }, 10L, 10L);
    }

    private void onWorldReady(Player p1, Player p2, Arena arena, String templateWorld, String copyName) {
        pendingStart.remove(p1.getUniqueId());
        pendingStart.remove(p2.getUniqueId());
        World world = Bukkit.getWorld(copyName);
        if (world == null) { abortStart(p1, p2); return; }
        plugin.getArenaManager().tuneWorld(world);

        // تطبيق إعدادات الأرينا على العالم المنسوخ فقط
        world.setGameRule(org.bukkit.GameRule.DO_TILE_DROPS, arena.isAllowBreaking());
        org.bukkit.Difficulty diff = switch (arena.getDifficulty()) {
            case "easy" -> org.bukkit.Difficulty.EASY;
            case "hard" -> org.bukkit.Difficulty.HARD;
            default     -> org.bukkit.Difficulty.NORMAL;
        };
        world.setDifficulty(diff);

        // Get spawn locations — P1 = index 0, P2 = index 1
        Location spawn1 = getSpawn(arena, templateWorld, world, 0);
        Location spawn2 = getSpawn(arena, templateWorld, world, 1);

        // Teleport
        p1.teleport(spawn1);
        p2.teleport(spawn2);

        // Create session
        DuelSession session = new DuelSession(p1, p2, arena, copyName);
        session.setPlayerSpawn(p1, spawn1);
        session.setPlayerSpawn(p2, spawn2);
        sessions.put(session.getSessionId(), session);
        playerSession.put(p1.getUniqueId(), session);
        playerSession.put(p2.getUniqueId(), session);

        // Apply kits — player personal arrangement takes priority over arena default
        // (كل خطوة محمية بـ try/catch حتى لو فشلت وحدة ما يتعطل العدّاد و GO)
        String kitName = arena.getKitName() != null ? arena.getKitName() : arena.getId();
        try {
            Kit defaultKit = plugin.getKitManager().getKit(kitName);
            applyPersonalOrDefault(p1, arena.getId(), defaultKit);
            applyPersonalOrDefault(p2, arena.getId(), defaultKit);
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] Failed applying kits", t);
        }

        // Apply saved armor trims on top of the kit (scoped to this arena)
        try {
            applyTrimsToPlayer(p1, arena.getId());
            applyTrimsToPlayer(p2, arena.getId());
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] Failed applying trims", t);
        }

        // Freeze players
        p1.setInvulnerable(true);
        p2.setInvulnerable(true);

        // Force both players to see each other, even if "Hide Players" is enabled
        try {
            p1.showPlayer(plugin, p2);
            p2.showPlayer(plugin, p1);
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] showPlayer failed", t);
        }

        // ── عزل الـ TAB — يشوف كل لاعب بس خصمه ──
        try {
            plugin.getTabIsolationManager().isolate(List.of(p1, p2));
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] TAB isolation failed", t);
        }

        // Countdown
        startCountdown(session, p1, p2);
    }

    public Location getSpawn(Arena arena, String templateWorldName, World copiedWorld, int playerIndex) {
        // Try exact template world name first
        Location loc = arena.getSpawn(templateWorldName, playerIndex);

        // Fallback: try any stored world's spawns
        if (loc == null) {
            for (List<org.bukkit.Location> spawns : arena.getSpawnPoints().values()) {
                if (spawns.size() > playerIndex) { loc = spawns.get(playerIndex); break; }
                if (!spawns.isEmpty())            { loc = spawns.get(0); break; }
            }
        }

        if (loc == null) {
            plugin.getLogger().warning("[DuelManager] No spawn found for arena '"
                    + arena.getId() + "' world '" + templateWorldName + "' — using world spawn.");
            return copiedWorld.getSpawnLocation();
        }

        // Always adapt to the copied world (handles null-world lazy locations too)
        // pitch = 0 دائماً: نقطة الـ spawn تُحفظ بزاوية رأس الأدمن وقت الضغط (غالباً ينظر لأسفل)
        return new Location(copiedWorld, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), 0f);
    }

    private void startCountdown(DuelSession session, Player p1, Player p2) {
        final int seconds = Math.max(1, plugin.getConfig().getInt("settings.countdown-seconds", 5));
        session.markCountdownStart();

        // مؤقت واحد فقط يتحكم بالعدّاد و GO (قبل كان فيه مؤقتين منفصلين ويمكن يختل التزامن بينهم)
        final AtomicInteger remaining = new AtomicInteger(seconds);
        final BukkitTask[] holder = new BukkitTask[1];

        holder[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            try {
                // انتهت الجلسة أثناء العدّ (disconnect / leave) — نوقف المؤقت
                if (session.getState() != DuelSession.State.COUNTDOWN) {
                    if (holder[0] != null) holder[0].cancel();
                    session.setCountdownTask(null);
                    return;
                }
                int current = remaining.getAndDecrement();
                if (current > 0) {
                    if (p1.isOnline()) { TitleUtils.sendCountdown(p1, current); SoundUtils.playCountdown(p1); }
                    if (p2.isOnline()) { TitleUtils.sendCountdown(p2, current); SoundUtils.playCountdown(p2); }
                } else {
                    if (holder[0] != null) holder[0].cancel();
                    session.setCountdownTask(null);
                    beginFight(session);
                }
            } catch (Throwable t) {
                plugin.getLogger().log(java.util.logging.Level.SEVERE, "[DuelManager] Countdown error — forcing fight start", t);
                if (holder[0] != null) holder[0].cancel();
                session.setCountdownTask(null);
                beginFight(session);
            }
        }, 0L, 20L);

        // نحفظ الـ task في الجلسة حتى يمكن إلغاؤها لو انتهت المباراة مبكراً
        session.setCountdownTask(holder[0]);

        // شبكة أمان: لو لأي سبب المؤقت ما كمل (تأخر السيرفر، إلغاء المهمة…) نبدأ القتال إجبارياً
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (session.getState() == DuelSession.State.COUNTDOWN) {
                plugin.getLogger().warning("[DuelManager] Countdown watchdog fired — forcing GO for session " + session.getSessionId());
                if (session.getCountdownTask() != null) {
                    session.getCountdownTask().cancel();
                    session.setCountdownTask(null);
                }
                beginFight(session);
            }
        }, (long) (seconds + 3) * 20L);
    }

    /**
     * يبدأ القتال فعلياً: يفك التجميد، يحوّل الحالة إلى FIGHTING، ويرسل GO.
     * آمن للاستدعاء أكثر من مرة (يشتغل مرة وحدة فقط).
     * الترتيب مهم: الحالة و فك التجميد أولاً، وأي شي ثانوي (سكوربورد/تايتل) داخل try/catch
     * عشان أي خطأ فيه ما يمنع GO أو الضرب.
     */
    public void beginFight(DuelSession session) {
        if (session.getState() != DuelSession.State.COUNTDOWN) return;

        Player p1 = session.getPlayer1();
        Player p2 = session.getPlayer2();

        // 1) الحالة أولاً — هذا اللي يسمح بالضرب
        session.setState(DuelSession.State.FIGHTING);
        session.markStarted();

        // 2) فك التجميد
        for (Player p : new Player[]{p1, p2}) {
            try {
                if (p.isOnline()) {
                    p.setInvulnerable(false);
                    p.setWalkSpeed(0.2f);
                    p.setFlySpeed(0.1f);
                }
            } catch (Throwable t) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] Unfreeze failed for " + p.getName(), t);
            }
        }

        // 3) GO! (قبل السكوربورد عشان ما يتأخر)
        for (Player p : new Player[]{p1, p2}) {
            try {
                if (p.isOnline()) { TitleUtils.sendGo(p); SoundUtils.playGo(p); }
            } catch (Throwable t) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] GO title failed for " + p.getName(), t);
            }
        }

        // 4) Scoreboard ping live
        try {
            plugin.getDuelScoreboardManager().start(session);
        } catch (Throwable t) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "[DuelManager] Scoreboard start failed", t);
        }
    }

    /**
     * شبكة أمان تُستدعى من DuelListener: لو الجلسة لسا COUNTDOWN مع إن وقت العدّ مرّ بالكامل
     * نبدأ القتال فوراً بدل ما يظل اللاعب عالق.
     */
    public boolean ensureFightStarted(DuelSession session) {
        if (session.getState() == DuelSession.State.FIGHTING) return true;
        if (session.getState() != DuelSession.State.COUNTDOWN) return false;
        int seconds = Math.max(1, plugin.getConfig().getInt("settings.countdown-seconds", 5));
        long elapsed = System.currentTimeMillis() - session.getCountdownStartMs();
        if (elapsed >= (seconds + 2) * 1000L) {
            plugin.getLogger().warning("[DuelManager] Session stuck in COUNTDOWN — forcing fight start");
            if (session.getCountdownTask() != null) {
                session.getCountdownTask().cancel();
                session.setCountdownTask(null);
            }
            beginFight(session);
            return true;
        }
        return false;
    }

    // ─────────────────────────────────────────
    //  End duel
    // ─────────────────────────────────────────

    public void endDuel(DuelSession session, Player winner) {
        if (session.getState() == DuelSession.State.ENDED) return;
        session.setState(DuelSession.State.ENDED);
        // Bug fix: إلغاء الـ countdown task إذا مات اللاعب خلال العدّ التنازلي
        if (session.getCountdownTask() != null) {
            session.getCountdownTask().cancel();
            session.setCountdownTask(null);
        }
        session.setWinner(winner);

        // ── فك التجميد دائماً (لو انتهى الدول أثناء العدّ التنازلي walkSpeed يبقى 0) ──
        unfreeze(session.getPlayer1());
        unfreeze(session.getPlayer2());

        // ── إزالة عزل الـ TAB ──
        plugin.getTabIsolationManager().restore(session.getPlayer1());
        plugin.getTabIsolationManager().restore(session.getPlayer2());

        // ── إيقاف الـ Scoreboard ──
        plugin.getDuelScoreboardManager().stop(session);

        Player loser = session.getLoser();

        // Eject spectators from the duel world before cleanup
        plugin.getSpectateCommand().ejectSpectators(session);

        // Record stats
        plugin.getStatsManager().recordWin(winner.getUniqueId(), winner.getName(), session.getArena().getId());
        plugin.getStatsManager().recordLoss(loser.getUniqueId(), loser.getName(), session.getArena().getId());

        // Refresh leaderboard holograms
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getHologramManager().refreshAll(), 20L);

        // Show results — فقط للاعبين الـ online
        if (winner.isOnline()) {
            TitleUtils.sendWinner(winner);
            SoundUtils.playWinner(winner);
        }
        if (loser.isOnline()) {
            TitleUtils.sendLoser(loser);
            SoundUtils.playLoser(loser);
        }

        // ── Clear inventories immediately so kit doesn't carry over to spawn ──
        if (winner.isOnline()) {
            winner.getInventory().clear();
            winner.setGameMode(GameMode.ADVENTURE);
        }
        if (loser.isOnline()) {
            loser.getInventory().clear();
            loser.setGameMode(GameMode.SPECTATOR);
        }

        // ── Offer rematch AFTER clearing inventories ──
        int rematchDelay = plugin.getConfig().getInt("settings.winner-delay-seconds", 5);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (winner.isOnline() && loser.isOnline()) {
                plugin.getRematchManager().offer(winner, loser, session.getArena());
            }
        }, rematchDelay * 20L);

        // Winner → send to spawn if no rematch offered (one-shot fallback, runs 2 ticks AFTER offer)
        // المشكلة السابقة: rematchDelay و winnerDelay كانوا نفس القيمة فكان Bukkit أحياناً يشغّل
        // الـ spawn-fallback قبل offer()، فيشوف isOffering=false ويطير للسبون بدون hotbar لأن
        // RematchManager ما أُبلغ بعد. الحل: نزيد تأخير الـ fallback بـ 2 tick فقط لضمان الترتيب.
        int winnerDelay = plugin.getConfig().getInt("settings.winner-delay-seconds", 5);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!winner.isOnline()) return;
            // If rematch is pending, RematchManager will handle teleport + hotbar
            if (plugin.getRematchManager().isOffering(winner)) return;
            // No rematch offered — send to spawn now
            winner.setGameMode(GameMode.SURVIVAL);
            winner.teleport(getServerSpawn());
            giveMenuSword(winner);
            plugin.getSettingsManager().applyEffect(winner,
                    com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS,
                    plugin.getSettingsManager().isEnabled(winner.getUniqueId(),
                            com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS));
        }, winnerDelay * 20L + 2L); // +2 ticks بعد offer لضمان isOffering() صحيحة

        // Loser — لو offline ما نحتاج نفعل شيء (يرجع للسبون عند rejoin)
        int loserDelay = plugin.getConfig().getInt("settings.loser-spectator-seconds", 5);
        if (loser.isOnline()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!loser.isOnline()) return;
                // If rematch is pending, RematchManager will handle teleport + hotbar
                if (plugin.getRematchManager().isOffering(loser)) return;
                // No rematch offered — send to spawn now
                loser.setGameMode(GameMode.SURVIVAL);
                loser.teleport(getServerSpawn());
                giveMenuSword(loser);
                plugin.getSettingsManager().applyEffect(loser,
                        com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS,
                        plugin.getSettingsManager().isEnabled(loser.getUniqueId(),
                                com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS));
            }, loserDelay * 20L + 2L); // +2 ticks بعد offer لضمان isOffering() صحيحة
        }

        // Clean up session and delete world (after both have been teleported)
        int cleanupDelay = Math.max(winnerDelay, loserDelay) + 2;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            sessions.remove(session.getSessionId());
            playerSession.remove(session.getPlayer1().getUniqueId(), session); // نفس الجلسة فقط (لا نمسح جلسة ريماتش جديدة)
            playerSession.remove(session.getPlayer2().getUniqueId(), session); // نفس الجلسة فقط (لا نمسح جلسة ريماتش جديدة)

            // Safety: teleport anyone still in the duel world to server spawn
            String copyName = session.getCopiedWorldName();
            org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(copyName);
            if (duelWorld != null && !duelWorld.getPlayers().isEmpty()) {
                org.bukkit.Location fallback = getServerSpawn();
                for (Player stuckPlayer : new java.util.ArrayList<>(duelWorld.getPlayers())) {
                    stuckPlayer.teleport(fallback);
                }
                // Give Bukkit one more tick to process teleports before deleting
                plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                        plugin.getArenaManager().deleteWorld(copyName), 5L);
            } else {
                plugin.getArenaManager().deleteWorld(copyName);
            }
        }, cleanupDelay * 20L);
    }

    /**
     * يُنظف الجلسة بدون إعلان فائز — يُستخدم لما الاثنين offline.
     */
    public void forceCleanup(com.duel.models.DuelSession session) {
        if (session.getState() == com.duel.models.DuelSession.State.ENDED) return;
        session.setState(com.duel.models.DuelSession.State.ENDED);
        if (session.getPingTask() != null) session.getPingTask().cancel();
        if (session.getCountdownTask() != null) {
            session.getCountdownTask().cancel();
            session.setCountdownTask(null);
        }
        unfreeze(session.getPlayer1());
        unfreeze(session.getPlayer2());
        sessions.remove(session.getSessionId());
        playerSession.remove(session.getPlayer1().getUniqueId(), session); // نفس الجلسة فقط (لا نمسح جلسة ريماتش جديدة)
        playerSession.remove(session.getPlayer2().getUniqueId(), session); // نفس الجلسة فقط (لا نمسح جلسة ريماتش جديدة)

        // Teleport any players still in the duel world before deleting
        String copyName = session.getCopiedWorldName();
        org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(copyName);
        if (duelWorld != null) {
            org.bukkit.Location fallback = getServerSpawn();
            for (Player stuckPlayer : new java.util.ArrayList<>(duelWorld.getPlayers())) {
                stuckPlayer.teleport(fallback);
            }
            plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                    plugin.getArenaManager().deleteWorld(copyName), 5L);
        } else {
            plugin.getArenaManager().deleteWorld(copyName);
        }
    }

    public int getActiveCountForArena(String arenaId) {
        return (int) sessions.values().stream()
                .filter(s -> s.getState() == DuelSession.State.FIGHTING
                          && s.getArena().getId().equalsIgnoreCase(arenaId))
                .count();
    }

    public java.util.Collection<DuelSession> getAllActiveSessions() {
        return sessions.values().stream()
                .filter(s -> s.getState() == DuelSession.State.FIGHTING)
                .toList();
    }

    public void cleanupAll() {
        for (DuelSession session : new ArrayList<>(sessions.values())) {
            plugin.getArenaManager().deleteWorld(session.getCopiedWorldName());
        }
        sessions.clear();
        playerSession.clear();
    }

    // ─────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────

    public DuelSession getSession(Player player) {
        return playerSession.get(player.getUniqueId());
    }

    public boolean isInDuel(Player player) {
        return playerSession.containsKey(player.getUniqueId()) || pendingStart.contains(player.getUniqueId());
    }

    private Location getServerSpawn() {
        return plugin.getSpawnManager().getSpawn();
    }

    private void giveMenuSword(Player player) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getPlayerJoinListener().giveDuelSword(player);
            // Restore party hotbar items if player is in a party
            plugin.getPartyManager().refreshHotbar(player);
        }, 5L);
    }

    /** Apply the player's personal kit arrangement if they have one, else the arena default. */
    private void applyPersonalOrDefault(Player player, String arenaId, Kit defaultKit) {
        org.bukkit.inventory.ItemStack[] personal =
                plugin.getPlayerKitManager().getPlayerKit(player.getUniqueId(), arenaId);

        if (personal != null) {
            // Apply personal arrangement directly
            player.getInventory().clear();
            com.duel.models.Kit personalKit = new com.duel.models.Kit("__personal__", personal);
            plugin.getKitManager().applyKit(player, personalKit);
        } else if (defaultKit != null) {
            plugin.getKitManager().applyKit(player, defaultKit);
        }
    }

    /**
     * Apply the player's saved armor trims (for the given arena) to whatever armor
     * they currently have equipped. Must be called AFTER applyPersonalOrDefault so
     * armor is already set.
     */
    private void applyTrimsToPlayer(Player player, String arenaId) {
        org.bukkit.inventory.PlayerInventory inv = player.getInventory();
        TrimManager trimManager = plugin.getTrimManager();
        UUID uuid = player.getUniqueId();

        org.bukkit.inventory.ItemStack[] trimmed = trimManager.applyTrims(
            player,
            arenaId,
            inv.getHelmet(),
            inv.getChestplate(),
            inv.getLeggings(),
            inv.getBoots()
        );
        // trimmed order: HELMET, CHESTPLATE, LEGGINGS, BOOTS
        if (trimmed[0] != null) inv.setHelmet(trimmed[0]);
        if (trimmed[1] != null) inv.setChestplate(trimmed[1]);
        if (trimmed[2] != null) inv.setLeggings(trimmed[2]);
        if (trimmed[3] != null) inv.setBoots(trimmed[3]);
        player.updateInventory();
    }

    /** Called from DuelListener when a player dies in a duel */
    public void onPlayerDeath(Player dead) {
        DuelSession session = getSession(dead);
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;
        Player opponent = session.getOpponent(dead);
        endDuel(session, opponent);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
