package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.DuelSession;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

public class DuelScoreboardManager {

    private final DuelPlugin plugin;

    public DuelScoreboardManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ── قراءة الكونفق مع دعم & للألوان ─────────────────────────────────
    private String cfg(String path) {
        String raw = plugin.getConfig().getString(path, "");
        return ChatColor.translateAlternateColorCodes('&', raw);
    }

    // ── استبدال الـ placeholders في خط ─────────────────────────────────
    private String applyPlaceholders(String template,
                                     String self, int selfPing,
                                     String opponent, int oppPing,
                                     String time) {
        return template
            .replace("{self}",          self)
            .replace("{self_ping}",     String.valueOf(selfPing))
            .replace("{opponent}",      opponent)
            .replace("{opponent_ping}", String.valueOf(oppPing))
            .replace("{time}",          time);
    }

    // ── تنسيق الوقت ─────────────────────────────────────────────────────
    private String formatTime(long startTime) {
        long seconds = (System.currentTimeMillis() - startTime) / 1000;
        long hours   = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs    = seconds % 60;
        if (hours > 0)
            return String.format("%dh %02dm %02ds", hours, minutes, secs);
        return String.format("%dm %02ds", minutes, secs);
    }

    // ── بناء السكوربورد ──────────────────────────────────────────────────
    public void start(DuelSession session) {
        Player p1 = session.getPlayer1();
        Player p2 = session.getPlayer2();

        Scoreboard board1 = buildBoard(p1, p2, session);
        Scoreboard board2 = buildBoard(p2, p1, session);
        p1.setScoreboard(board1);
        p2.setScoreboard(board2);
        session.setTabScoreboard(board1);

        org.bukkit.scheduler.BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (session.getState() == DuelSession.State.ENDED) return;
            if (p1.isOnline()) refresh(board1, p1, p2, session);
            if (p2.isOnline()) refresh(board2, p2, p1, session);
        }, 20L, 20L);

        session.setPingTask(task);
    }

    public void stop(DuelSession session) {
        if (session.getPingTask() != null) {
            session.getPingTask().cancel();
            session.setPingTask(null);
        }
        org.bukkit.scoreboard.Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        Player p1 = session.getPlayer1();
        Player p2 = session.getPlayer2();
        if (p1.isOnline()) p1.setScoreboard(main);
        if (p2.isOnline()) p2.setScoreboard(main);
    }

    private Scoreboard buildBoard(Player self, Player opponent, DuelSession session) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        String title = cfg("scoreboard.title");
        Objective obj = board.registerNewObjective("duel_sb", "dummy", title);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        setLines(obj, self, opponent, session);
        return board;
    }

    private void refresh(Scoreboard board, Player self, Player opponent, DuelSession session) {
        Objective obj = board.getObjective("duel_sb");
        if (obj == null) return;
        for (String e : board.getEntries()) board.resetScores(e);
        setLines(obj, self, opponent, session);
    }

    private void setLines(Objective obj, Player self, Player opponent, DuelSession session) {
        FileConfiguration c = plugin.getConfig();

        String time = formatTime(session.getStartTime());

        // ── اقرأ الخطوط من الكونفق ───────────────────────────────────────
        String sepTop  = cfg("scoreboard.separator-top");
        String sepBot  = cfg("scoreboard.separator-bottom");
        String footer  = cfg("scoreboard.footer");
        String timeTpl = cfg("scoreboard.time-line");
        String selfTpl = cfg("scoreboard.self-line");
        String oppTpl  = cfg("scoreboard.opponent-line");

        String selfLine = applyPlaceholders(selfTpl,
                self.getName(), self.getPing(),
                opponent.getName(), opponent.getPing(), time);

        String oppLine = applyPlaceholders(oppTpl,
                self.getName(), self.getPing(),
                opponent.getName(), opponent.getPing(), time);

        String timeLine = applyPlaceholders(timeTpl,
                self.getName(), self.getPing(),
                opponent.getName(), opponent.getPing(), time);

        // ── ترتيب الأسطر (من أعلى = أعلى score) ────────────────────────
        obj.getScore(sepTop).setScore(7);
        obj.getScore(selfLine).setScore(6);
        obj.getScore(oppLine).setScore(5);
        obj.getScore(sepBot).setScore(4);
        obj.getScore(" ").setScore(3);
        obj.getScore(timeLine).setScore(2);
        obj.getScore("  ").setScore(1);
        obj.getScore(footer).setScore(0);
    }
}
