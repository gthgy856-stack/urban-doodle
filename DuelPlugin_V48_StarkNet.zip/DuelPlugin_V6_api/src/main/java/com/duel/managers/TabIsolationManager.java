package com.duel.managers;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.*;

/**
 * يعزل الـ TAB list لمجموعة لاعبين — كل لاعب يشوف بس اللاعبين اللي في نفس المجموعة.
 *
 * يعمل عبر إرسال PacketPlayOutPlayerInfo (REMOVE) لكل لاعب خارج المجموعة
 * ويحفظ قائمة "المخفيّين" لكل لاعب حتى يقدر يسترجعهم عند الخروج.
 *
 * Supports Paper 1.21.4 via reflection-based packet sending.
 */
public class TabIsolationManager {

    /** playerUUID → قائمة UUIDs المخفيّة عنه */
    private final Map<UUID, Set<UUID>> hiddenFromPlayer = new HashMap<>();

    /**
     * يطبّق عزل TAB على مجموعة لاعبين.
     * كل لاعب في المجموعة يشوف بس اللاعبين اللي فيها.
     *
     * @param group المجموعة المراد عزلها
     */
    public void isolate(List<Player> group) {
        Set<UUID> groupUUIDs = new HashSet<>();
        for (Player p : group) groupUUIDs.add(p.getUniqueId());

        Collection<? extends Player> online = Bukkit.getOnlinePlayers();

        for (Player viewer : group) {
            Set<UUID> toHide = new HashSet<>();

            for (Player other : online) {
                if (!groupUUIDs.contains(other.getUniqueId())) {
                    // أخفِ هذا اللاعب من viewer
                    hideFromTab(viewer, other);
                    toHide.add(other.getUniqueId());
                }
            }

            hiddenFromPlayer.put(viewer.getUniqueId(), toHide);
        }
    }

    /**
     * يسترجع الـ TAB الكامل للاعب (عند انتهاء المباراة).
     *
     * @param player اللاعب المراد إعادة TAB الكامل له
     */
    public void restore(Player player) {
        Set<UUID> hidden = hiddenFromPlayer.remove(player.getUniqueId());
        if (hidden == null || hidden.isEmpty()) return;

        for (UUID uuid : hidden) {
            Player target = Bukkit.getPlayer(uuid);
            if (target != null && target.isOnline()) {
                showInTab(player, target);
            }
        }
    }

    /**
     * يسترجع TAB الكامل لكل اللاعبين في المجموعة.
     */
    public void restoreAll(List<Player> group) {
        for (Player p : group) {
            if (p.isOnline()) restore(p);
        }
    }

    /**
     * عندما ينضم لاعب جديد للسيرفر — نضيفه للـ hidden list لكل اللاعبين المعزولين.
     */
    public void onPlayerJoin(Player joined) {
        for (Map.Entry<UUID, Set<UUID>> entry : hiddenFromPlayer.entrySet()) {
            Player viewer = Bukkit.getPlayer(entry.getKey());
            if (viewer == null || !viewer.isOnline()) continue;
            // اللاعب الجديد ليس في مجموعة الـ viewer — أخفِه
            hideFromTab(viewer, joined);
            entry.getValue().add(joined.getUniqueId());
        }
    }

    public boolean isIsolated(Player player) {
        return hiddenFromPlayer.containsKey(player.getUniqueId());
    }

    // ──────────────────────────────────────────────
    //  Packet helpers — Paper 1.21.4
    // ──────────────────────────────────────────────

    /**
     * يخفي `target` من TAB list الخاص بـ `viewer`
     * عبر إرسال ClientboundPlayerInfoRemovePacket.
     */
    private void hideFromTab(Player viewer, Player target) {
        try {
            // Paper 1.21: player.hidePlayer(plugin, target) يخفيه من العالم
            // لكن ما يخفيه من TAB — نحتاج packet مباشر.
            // نستخدم getHandle().connection.send() عبر reflection

            Object handle = getHandle(viewer);
            Object connection = getField(handle, "connection");
            Object packet = buildRemovePacket(target.getUniqueId());
            sendPacket(connection, packet);
        } catch (Exception e) {
            // fallback: لا نفعل شيئاً — الـ TAB سيبقى مرئياً
        }
    }

    /**
     * يُعيد إظهار `target` في TAB list الخاص بـ `viewer`
     * عبر إرسال ClientboundPlayerInfoUpdatePacket (ADD_PLAYER).
     */
    private void showInTab(Player viewer, Player target) {
        try {
            Object handle = getHandle(viewer);
            Object connection = getField(handle, "connection");
            Object packet = buildAddPacket(target);
            sendPacket(connection, packet);
        } catch (Exception e) {
            // fallback: لا نفعل شيئاً
        }
    }

    // ── NMS Reflection ──────────────────────────────

    private static Object getHandle(Player player) throws Exception {
        Method getHandle = player.getClass().getMethod("getHandle");
        return getHandle.invoke(player);
    }

    private static Object getField(Object obj, String name) throws Exception {
        java.lang.reflect.Field f = findField(obj.getClass(), name);
        f.setAccessible(true);
        return f.get(obj);
    }

    private static java.lang.reflect.Field findField(Class<?> cls, String name) throws NoSuchFieldException {
        while (cls != null) {
            try { return cls.getDeclaredField(name); }
            catch (NoSuchFieldException ignored) {}
            cls = cls.getSuperclass();
        }
        throw new NoSuchFieldException(name);
    }

    private static void sendPacket(Object connection, Object packet) throws Exception {
        // Paper 1.21: ServerGamePacketListenerImpl.send(Packet)
        for (Method m : connection.getClass().getMethods()) {
            if (m.getName().equals("send") && m.getParameterCount() == 1) {
                Class<?> paramType = m.getParameterTypes()[0];
                if (paramType.isAssignableFrom(packet.getClass())) {
                    m.invoke(connection, packet);
                    return;
                }
            }
        }
    }

    /**
     * يبني ClientboundPlayerInfoRemovePacket لـ UUID واحد.
     * net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket(List<UUID>)
     */
    private static Object buildRemovePacket(UUID uuid) throws Exception {
        Class<?> cls = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket");
        return cls.getConstructor(List.class).newInstance(Collections.singletonList(uuid));
    }

    /**
     * يبني ClientboundPlayerInfoUpdatePacket لإعادة إضافة لاعب.
     * نستخدم الـ static factory: ClientboundPlayerInfoUpdatePacket.createPlayerInitializing(Collection)
     */
    private static Object buildAddPacket(Player target) throws Exception {
        Object nmsPlayer = getHandle(target);
        Class<?> cls = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
        Method factory = cls.getMethod("createPlayerInitializing", Collection.class);
        return factory.invoke(null, Collections.singletonList(nmsPlayer));
    }
}
