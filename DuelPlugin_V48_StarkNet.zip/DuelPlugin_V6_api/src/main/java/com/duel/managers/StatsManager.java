package com.duel.managers;

import com.duel.DuelPlugin;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class StatsManager {

    public enum TopType { WINS, LOSSES, STREAK, POINTS }

    public record PlayerStats(String name, UUID uuid, int wins, int losses, int streak, int bestStreak, int points) {}

    private final DuelPlugin plugin;

    // ── Top-10 cache ────────────────────────────────────────────────────
    // Reading top10/topGlobal used to run a live SQL query (GROUP BY / ORDER BY)
    // on whichever thread called it — including the MAIN thread every time a
    // %duel_top_*% placeholder was resolved (TAB, scoreboards, etc). With
    // several online players that meant repeated synchronous DB hits per
    // second and visible lag/freezes. Now a background task refreshes this
    // cache periodically and getTop10()/getTopGlobal() just read from memory.
    private final Map<String, List<PlayerStats>> topCache = new ConcurrentHashMap<>();
    private static final long CACHE_REFRESH_TICKS = 100L; // 5 seconds
    private static final long FORCED_REFRESH_MS = 5 * 60 * 1000L;

    private final java.util.concurrent.atomic.AtomicBoolean dirty = new java.util.concurrent.atomic.AtomicBoolean(true);
    private final java.util.concurrent.atomic.AtomicLong lastRefresh = new java.util.concurrent.atomic.AtomicLong(0L);

    // ── Per-player stats cache ───────────────────────────────────────────
    // Keyed by UUID → aggregated (SUM across all arenas) PlayerStats.
    // Refreshed on the same background cycle as the top-10 cache.
    private final Map<UUID, PlayerStats> playerStatsCache = new ConcurrentHashMap<>();

    public StatsManager(DuelPlugin plugin) {
        this.plugin = plugin;
        startCacheRefresher();
    }

    private void startCacheRefresher() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            boolean forced = System.currentTimeMillis() - lastRefresh.get() >= FORCED_REFRESH_MS;
            if (!dirty.getAndSet(false) && !forced) return;
            lastRefresh.set(System.currentTimeMillis());

            // Snapshot arena IDs on the MAIN thread — ArenaManager's internal map
            // isn't thread-safe, so we must not iterate it from the async task below.
            List<String> arenaIds = new ArrayList<>();
            for (com.duel.models.Arena arena : plugin.getArenaManager().getAllArenas()) {
                arenaIds.add(arena.getId());
            }

            // Now do the actual (heavier) DB work off-thread.
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                for (TopType type : TopType.values()) {
                    topCache.put(cacheKey(null, type), queryTopGlobal(type));
                    for (String arenaId : arenaIds) {
                        topCache.put(cacheKey(arenaId, type), queryTop10(arenaId, type));
                    }
                }
                refreshPlayerStatsCache();
            });
        }, 20L, CACHE_REFRESH_TICKS);
    }

    private String cacheKey(String arenaId, TopType type) {
        return (arenaId == null ? "*global*" : arenaId.toLowerCase()) + ":" + type;
    }

    // ─────────────────────────────────────────
    //  Record win
    // ─────────────────────────────────────────

    public void recordWin(UUID uuid, String playerName, String arenaId) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO stats (uuid, arena_id, name, wins, losses, streak, best_streak, points)
                    VALUES (?, ?, ?, 1, 0, 1, 1, 1)
                    ON CONFLICT(uuid, arena_id) DO UPDATE SET
                        name        = excluded.name,
                        wins        = wins + 1,
                        streak      = streak + 1,
                        best_streak = MAX(best_streak, streak + 1),
                        points      = points + 1
                 """)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, arenaId);
                ps.setString(3, playerName);
                ps.executeUpdate();
                dirty.set(true);
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to record win", e);
            }
        });
    }

    // ─────────────────────────────────────────
    //  Record loss
    // ─────────────────────────────────────────

    public void recordLoss(UUID uuid, String playerName, String arenaId) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO stats (uuid, arena_id, name, wins, losses, streak, best_streak, points)
                    VALUES (?, ?, ?, 0, 1, 0, 0, -1)
                    ON CONFLICT(uuid, arena_id) DO UPDATE SET
                        name   = excluded.name,
                        losses = losses + 1,
                        streak = 0,
                        points = points - 1
                 """)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, arenaId);
                ps.setString(3, playerName);
                ps.executeUpdate();
                dirty.set(true);
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to record loss", e);
            }
        });
    }

    // ─────────────────────────────────────────
    //  Top 10
    // ─────────────────────────────────────────

    /** Reads from the periodically-refreshed cache — no DB I/O, safe to call from the main thread. */
    public List<PlayerStats> getTop10(String arenaId, TopType type) {
        return topCache.getOrDefault(cacheKey(arenaId, type), List.of());
    }

    private List<PlayerStats> queryTop10(String arenaId, TopType type) {
        String orderCol = switch (type) {
            case WINS   -> "wins";
            case LOSSES -> "losses";
            case STREAK -> "best_streak";
            case POINTS -> "points";
        };

        List<PlayerStats> result = new ArrayList<>();
        try (Connection conn = plugin.getDatabaseManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "SELECT uuid, name, wins, losses, streak, best_streak, points " +
                "FROM stats WHERE arena_id = ? ORDER BY " + orderCol + " DESC LIMIT 10")) {
            ps.setString(1, arenaId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                result.add(new PlayerStats(
                        rs.getString("name"),
                        UUID.fromString(rs.getString("uuid")),
                        rs.getInt("wins"),
                        rs.getInt("losses"),
                        rs.getInt("streak"),
                        rs.getInt("best_streak"),
                        rs.getInt("points")
                ));
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to fetch top 10", e);
        }
        return result;
    }
    // ─────────────────────────────────────────
    //  Top 10 — all arenas combined (SUM per player)
    // ─────────────────────────────────────────

    /** Reads from the periodically-refreshed cache — no DB I/O, safe to call from the main thread. */
    public List<PlayerStats> getTopGlobal(TopType type) {
        return topCache.getOrDefault(cacheKey(null, type), List.of());
    }

    private List<PlayerStats> queryTopGlobal(TopType type) {
        String orderCol = switch (type) {
            case WINS   -> "total_wins";
            case LOSSES -> "total_losses";
            case STREAK -> "total_best_streak";
            case POINTS -> "total_points";
        };

        List<PlayerStats> result = new ArrayList<>();
        try (Connection conn = plugin.getDatabaseManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "SELECT uuid, name, " +
                "SUM(wins) AS total_wins, SUM(losses) AS total_losses, " +
                "SUM(streak) AS total_streak, SUM(best_streak) AS total_best_streak, " +
                "SUM(points) AS total_points " +
                "FROM stats GROUP BY uuid " +
                "ORDER BY " + orderCol + " DESC LIMIT 10")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                result.add(new PlayerStats(
                        rs.getString("name"),
                        UUID.fromString(rs.getString("uuid")),
                        rs.getInt("total_wins"),
                        rs.getInt("total_losses"),
                        rs.getInt("total_streak"),
                        rs.getInt("total_best_streak"),
                        rs.getInt("total_points")
                ));
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to fetch global top 10", e);
        }
        return result;
    }

    // ─────────────────────────────────────────
    //  Per-player stats (global sum)
    // ─────────────────────────────────────────

    /**
     * Returns the cached aggregated stats for a player across all arenas.
     * Returns null if the player has never played a duel.
     * Safe to call from the main thread — no DB I/O.
     */
    public PlayerStats getPlayerStats(UUID uuid) {
        return playerStatsCache.get(uuid);
    }

    /** Queries the DB and rebuilds playerStatsCache. Must be called off the main thread. */
    private void refreshPlayerStatsCache() {
        try (Connection conn = plugin.getDatabaseManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "SELECT uuid, name, " +
                "SUM(wins) AS total_wins, SUM(losses) AS total_losses, " +
                "SUM(streak) AS total_streak, SUM(best_streak) AS total_best_streak, " +
                "SUM(points) AS total_points " +
                "FROM stats GROUP BY uuid")) {
            ResultSet rs = ps.executeQuery();
            Map<UUID, PlayerStats> fresh = new HashMap<>();
            while (rs.next()) {
                UUID uid = UUID.fromString(rs.getString("uuid"));
                fresh.put(uid, new PlayerStats(
                        rs.getString("name"),
                        uid,
                        rs.getInt("total_wins"),
                        rs.getInt("total_losses"),
                        rs.getInt("total_streak"),
                        rs.getInt("total_best_streak"),
                        rs.getInt("total_points")
                ));
            }
            playerStatsCache.putAll(fresh);
            playerStatsCache.keySet().retainAll(fresh.keySet());
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to refresh player stats cache", e);
        }
    }
}
