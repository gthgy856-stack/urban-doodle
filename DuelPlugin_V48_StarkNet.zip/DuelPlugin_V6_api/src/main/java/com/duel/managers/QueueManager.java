package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.managers.SettingsManager;
import com.duel.models.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class QueueManager {

    private final DuelPlugin plugin;

    // arenaId → ordered list of waiting players
    private final Map<String, List<Player>> queues = new HashMap<>();
    // player → arenaId they're queued for
    private final Map<UUID, String> playerArena = new HashMap<>();
    // player → task for actionbar update
    private final Map<UUID, BukkitTask> actionbarTasks = new HashMap<>();
    // player → queue start time (millis)
    private final Map<UUID, Long> joinTimes = new HashMap<>();

    public QueueManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isQueued(Player player) {
        return playerArena.containsKey(player.getUniqueId());
    }

    public String getQueuedArena(Player player) {
        return playerArena.get(player.getUniqueId());
    }

    /**
     * Add player to queue for a specific arena.
     * Returns the opponent if a match is found immediately, otherwise null.
     */
    public Player addToQueue(Player player, Arena arena) {
        // FIX: حماية مركزية — عضو البارتي ما يدخل كيو 1v1 من أي مسار
        if (plugin.getPartyManager().isInParty(player)) return null;

        String id = arena.getId().toLowerCase();

        queues.computeIfAbsent(id, k -> new ArrayList<>());
        List<Player> queue = queues.get(id);

        // Already in queue for this arena — ignore
        if (playerArena.containsKey(player.getUniqueId())) return null;

        // دخول الانتظار يلغي أي دعوة دول معلّقة (مرسلة أو مستلمة)
        plugin.getDuelRequestManager().cancelAllFor(player);

        queue.add(player);
        playerArena.put(player.getUniqueId(), id);
        joinTimes.put(player.getUniqueId(), System.currentTimeMillis());

        startActionbar(player, arena);

        // Check for match
        if (queue.size() >= 2) {
            Player p1 = queue.remove(0);
            Player p2 = queue.remove(0);
            playerArena.remove(p1.getUniqueId());
            playerArena.remove(p2.getUniqueId());
            joinTimes.remove(p1.getUniqueId());
            joinTimes.remove(p2.getUniqueId());
            stopActionbar(p1);
            stopActionbar(p2);
            return p1.equals(player) ? p2 : p1;
        }
        return null;
    }

    public void removeFromQueue(Player player) {
        String arenaId = playerArena.remove(player.getUniqueId());
        joinTimes.remove(player.getUniqueId());

        if (arenaId != null) {
            List<Player> queue = queues.get(arenaId);
            if (queue != null) queue.remove(player);
        }

        stopActionbar(player);
    }

    /** How many players are in queue for an arena (including this player) */
    public int getTotalQueued() {
        return playerArena.size();
    }

    public int getQueueSize(Arena arena) {
        List<Player> q = queues.get(arena.getId().toLowerCase());
        return q == null ? 0 : q.size();
    }

    // ─────────────────────────────────────────
    //  Actionbar
    // ─────────────────────────────────────────

    private void startActionbar(Player player, Arena arena) {
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || !isQueued(player)) {
                stopActionbar(player);
                return;
            }
            if (plugin.getSettingsManager().isEnabled(player.getUniqueId(), SettingsManager.Setting.HIDE_ACTIONBAR)) {
                player.sendActionBar(net.kyori.adventure.text.Component.empty());
                return;
            }
            long seconds = (System.currentTimeMillis() - joinTimes.getOrDefault(player.getUniqueId(), System.currentTimeMillis())) / 1000;
            int inQueue = getQueueSize(arena) + 1; // +1 because we removed this player already if match found

            Component bar = Component.text()
                    .append(Component.text("⚔ ", NamedTextColor.YELLOW))
                    .append(Component.text(arena.getId(), NamedTextColor.GREEN))
                    .append(Component.text("  │  ", NamedTextColor.DARK_GRAY))
                    .append(Component.text("1/2", NamedTextColor.AQUA))
                    .append(Component.text("  │  ", NamedTextColor.DARK_GRAY))
                    .append(Component.text(formatTime(seconds), NamedTextColor.YELLOW))
                    .build();

            player.sendActionBar(bar);
        }, 0L, 20L);

        // Bug fix: نوقف الـ task القديمة ونضيف الجديدة للماب قبل أي تأخير
        stopActionbar(player);
        actionbarTasks.put(player.getUniqueId(), task);
        // Note: الـ task تُشغَّل في نفس الـ tick (delay=0) فالترتيب هنا لا يسبب race
    }

    private void stopActionbar(Player player) {
        BukkitTask old = actionbarTasks.remove(player.getUniqueId());
        if (old != null) old.cancel();
        // Clear actionbar
        player.sendActionBar(Component.empty());
    }

    private String formatTime(long seconds) {
        long m = seconds / 60;
        long s = seconds % 60;
        return String.format("%02d:%02d", m, s);
    }
}
