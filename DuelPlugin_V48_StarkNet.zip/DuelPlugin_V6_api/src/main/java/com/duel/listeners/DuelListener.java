package com.duel.listeners;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.models.DuelSession;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class DuelListener implements Listener {

    private final DuelPlugin plugin;

    /** مكان موت اللاعب داخل عالم المباراة — يُستخدم لإرجاعه كمتفرج في نفس المكان */
    private final java.util.Map<java.util.UUID, Location> deathLocations = new java.util.HashMap<>();

    public DuelListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────
    //  Freeze — منع القفز أثناء التجهيز والعدّ التنازلي
    //  (walkSpeed=0 يمنع المشي فقط، فنمنع الحركة للأعلى هنا)
    //  التجميد في هذا البلغن = walkSpeed 0، يبدأ من "Match found"
    //  ويشمل 1v1 وParty وFFA حتى قبل إنشاء الجلسة.
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFrozenJump(PlayerMoveEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null || to.getY() <= from.getY()) return;

        Player p = event.getPlayer();
        if (p.getWalkSpeed() != 0f) return;
        if (p.getGameMode() == GameMode.SPECTATOR || p.isFlying()) return;

        // نبقي الدوران (yaw/pitch) ونثبّت الموقع
        Location fixed = from.clone();
        fixed.setYaw(to.getYaw());
        fixed.setPitch(to.getPitch());
        event.setTo(fixed);
    }

    // ─────────────────────────────────────────
    //  Death → end duel
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        // Party duel يتعامل معها PartyDuelListener
        if (plugin.getPartyDuelManager().isInPartyDuel(dead)) return;
        if (!plugin.getDuelManager().isInDuel(dead)) return;

        // Suppress death message and drops
        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        // احفظ مكان الموت (لإرجاعه كمتفرج داخل نفس العالم)
        deathLocations.put(dead.getUniqueId(), dead.getLocation().clone());

        // Trigger duel end
        plugin.getDuelManager().onPlayerDeath(dead);

        // تخطّي شاشة الموت: respawn تلقائي بعد tick
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (dead.isOnline() && dead.isDead()) dead.spigot().respawn();
        }, 1L);
    }

    // ─────────────────────────────────────────
    //  Respawn → send to arena (handled by DuelManager already)
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        Location death = deathLocations.remove(p.getUniqueId());
        if (plugin.getPartyDuelManager().isInPartyDuel(p)) return;

        DuelSession session = plugin.getDuelManager().getSession(p);
        if (session == null) return;

        World duelWorld = plugin.getServer().getWorld(session.getCopiedWorldName());
        if (duelWorld == null) return;

        // مكان الرجوع: مكان الموت داخل عالم المباراة، وإلا (فويد/عالم مختلف) نقطة سبون اللاعب في الأرينا
        Location respawnLoc = death;
        if (respawnLoc == null || respawnLoc.getWorld() == null
                || !respawnLoc.getWorld().equals(duelWorld)
                || respawnLoc.getY() < duelWorld.getMinHeight()) {
            Location spawn = session.getPlayerSpawn(p);
            respawnLoc = spawn != null ? spawn.clone().add(0, 3, 0) : duelWorld.getSpawnLocation();
        }
        event.setRespawnLocation(respawnLoc);

        // لو مات أثناء العد التنازلي (مثلاً فويد) — يرجع سبونه كلاعب عادي بدون spectator
        if (session.getState() == DuelSession.State.COUNTDOWN) return;

        // بعد النقل (tick) → سبكتيت + يتابع الخصم
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            // سبكتيت حر — بدون ربط الكاميرا بالخصم
            if (p.getGameMode() != GameMode.SPECTATOR) p.setGameMode(GameMode.SPECTATOR);
        }, 1L);
    }

    // ─────────────────────────────────────────
    //  Block break — enforce arena setting
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("duelplugin.admin")) return;

        DuelSession session = plugin.getDuelManager().getSession(player);
        if (session == null) return;

        Arena arena = session.getArena();
        if (arena == null) return;

        org.bukkit.Location loc = event.getBlock().getLocation();
        boolean isPlaced = session.isPlacedBlock(loc);

        if (isPlaced) {
            // بلوكة مبنية أثناء المباراة
            if (!arena.isAllowBreakPlaced()) {
                event.setCancelled(true);
                return;
            }
            // مسموح بتكسير المبنية — نشيلها من التتبع
            session.untrackBlock(loc);
        } else {
            // بلوكة أصلية من الماب
            if (!arena.isAllowBreaking()) {
                event.setCancelled(true);
            }
        }
    }

    // ─────────────────────────────────────────
    //  Block place — enforce arena setting
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("duelplugin.admin")) return;

        DuelSession session = plugin.getDuelManager().getSession(player);
        if (session == null) return;

        Arena arena = session.getArena();
        if (arena == null) return;

        if (!arena.isAllowBuilding()) {
            event.setCancelled(true);
            return;
        }

        // منع البناء أكثر من 30 بلوك فوق Y الإسبون
        org.bukkit.Location spawnLoc = session.getPlayerSpawn(player);
        if (spawnLoc != null && event.getBlock().getY() - spawnLoc.getBlockY() > 30) {
            event.setCancelled(true);
            return;
        }

        // تتبع البلوكة المبنية
        session.trackPlacedBlock(event.getBlock().getLocation(), player);
    }

    // ─────────────────────────────────────────
    //  PvP — only allow damage within active duels
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        // إذا أي منهم في party duel — PartyDuelListener تتعامل معها
        if (plugin.getPartyDuelManager().isInPartyDuel(attacker) ||
            plugin.getPartyDuelManager().isInPartyDuel(victim)) return;

        boolean attackerInDuel = plugin.getDuelManager().isInDuel(attacker);
        boolean victimInDuel   = plugin.getDuelManager().isInDuel(victim);

        // If neither is in a duel — let normal server rules apply
        if (!attackerInDuel && !victimInDuel) return;

        // If both are in a duel, check they're in the same session
        if (attackerInDuel && victimInDuel) {
            DuelSession aSession = plugin.getDuelManager().getSession(attacker);
            DuelSession vSession = plugin.getDuelManager().getSession(victim);

            if (aSession != null && aSession.equals(vSession)
                    && plugin.getDuelManager().ensureFightStarted(aSession)) {
                return; // valid duel fight — allow damage
            }
        }

        // Otherwise cancel
        event.setCancelled(true);
    }
}
