package com.duel.database;

import com.duel.DuelPlugin;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.sql.*;
import java.util.logging.Level;

/**
 * Central SQLite + HikariCP database manager.
 * Single database.db file — all tables inside.
 */
public class DatabaseManager {

    private final DuelPlugin plugin;
    private HikariDataSource dataSource;

    public DatabaseManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() {
        File dbFile = new File(plugin.getDataFolder(), "database.db");

        HikariConfig config = new HikariConfig();
        config.setDriverClassName("org.sqlite.JDBC");
        config.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        config.setConnectionTimeout(30000);
        config.setIdleTimeout(600000);
        config.setMaxLifetime(1800000);
        config.setPoolName("DuelPlugin-Pool");
        // SQLite pragmas must be applied via connectionInitSql, not DataSource properties
        config.setConnectionInitSql(
            "PRAGMA journal_mode=WAL; " +
            "PRAGMA synchronous=NORMAL; " +
            "PRAGMA cache_size=10000; " +
            "PRAGMA foreign_keys=ON;"
        );

        dataSource = new HikariDataSource(config);
        createTables();
        plugin.getLogger().info("[DuelPlugin] Database connected — database.db");
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    private void createTables() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arenas (
                    id             TEXT PRIMARY KEY,
                    kit_name       TEXT,
                    data           TEXT,
                    allow_breaking      INTEGER NOT NULL DEFAULT 0,
                    allow_building      INTEGER NOT NULL DEFAULT 0,
                    allow_break_placed  INTEGER NOT NULL DEFAULT 0,
                    difficulty          TEXT    NOT NULL DEFAULT 'normal',
                    menu_slot           INTEGER
                )
            """);
            // Migration: add columns if they don't exist (for existing DBs)
            try { stmt.execute("ALTER TABLE arenas ADD COLUMN allow_breaking INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
            try { stmt.execute("ALTER TABLE arenas ADD COLUMN allow_building INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
            try { stmt.execute("ALTER TABLE arenas ADD COLUMN allow_break_placed INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
            try { stmt.execute("ALTER TABLE arenas ADD COLUMN difficulty TEXT NOT NULL DEFAULT 'normal'");  } catch (Exception ignored) {}
            try { stmt.execute("ALTER TABLE arenas ADD COLUMN menu_slot INTEGER"); } catch (Exception ignored) {}

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS arena_worlds (
                    arena_id   TEXT NOT NULL,
                    world_name TEXT NOT NULL,
                    spawns     TEXT NOT NULL,
                    PRIMARY KEY (arena_id, world_name),
                    FOREIGN KEY (arena_id) REFERENCES arenas(id) ON DELETE CASCADE
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS kits (
                    name  TEXT PRIMARY KEY,
                    items TEXT NOT NULL
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS player_kits (
                    uuid     TEXT NOT NULL,
                    arena_id TEXT NOT NULL,
                    items    TEXT NOT NULL,
                    PRIMARY KEY (uuid, arena_id)
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS player_settings (
                    uuid                TEXT PRIMARY KEY,
                    hide_chat           INTEGER DEFAULT 0,
                    hide_scoreboard     INTEGER DEFAULT 0,
                    hide_players        INTEGER DEFAULT 0,
                    block_duel_requests INTEGER DEFAULT 0,
                    mute_sounds         INTEGER DEFAULT 0,
                    hide_actionbar      INTEGER DEFAULT 0,
                    hide_death_messages INTEGER DEFAULT 0,
                    hide_join_quit      INTEGER DEFAULT 0
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS stats (
                    uuid        TEXT NOT NULL,
                    arena_id    TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    wins        INTEGER DEFAULT 0,
                    losses      INTEGER DEFAULT 0,
                    streak      INTEGER DEFAULT 0,
                    best_streak INTEGER DEFAULT 0,
                    points      INTEGER DEFAULT 0,
                    PRIMARY KEY (uuid, arena_id)
                )
            """);

            // Migration: add points column for existing databases
            try { stmt.execute("ALTER TABLE stats ADD COLUMN points INTEGER DEFAULT 0"); }
            catch (SQLException ignored) { /* column already exists */ }

            stmt.execute("CREATE INDEX IF NOT EXISTS idx_stats_wins        ON stats(arena_id, wins DESC)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_stats_losses      ON stats(arena_id, losses DESC)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_stats_best_streak ON stats(arena_id, best_streak DESC)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_stats_points      ON stats(arena_id, points DESC)");

            plugin.getLogger().info("[DuelPlugin] All tables initialized.");

        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] Failed to create tables!", e);
        }
    }

    public void execute(String sql, Object... params) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "[DuelPlugin] SQL error: " + sql, e);
        }
    }
}
