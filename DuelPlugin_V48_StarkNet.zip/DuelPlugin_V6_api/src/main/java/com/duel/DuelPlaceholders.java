package com.duel;

import com.duel.managers.DuelManager;
import com.duel.managers.QueueManager;
import com.duel.managers.StatsManager;
import com.duel.managers.StatsManager.PlayerStats;
import com.duel.managers.StatsManager.TopType;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * PlaceholderAPI expansion for DuelPlugin — STARK NETWORK
 *
 * ═══════════════════════════════════════════════════
 *  GENERAL
 * ═══════════════════════════════════════════════════
 *  %duel_active%                        → عدد المبارزات النشطة الآن
 *  %duel_queued%                        → عدد اللاعبين في الانتظار
 *
 * ═══════════════════════════════════════════════════
 *  PERSONAL STATS  (للاعب الحالي — كل الأريناز مجموعة)
 * ═══════════════════════════════════════════════════
 *  %duel_wins_me%                       → عدد انتصارات اللاعب الحالي
 *  %duel_points_me%                     → عدد نقاط اللاعب الحالي
 *
 * ═══════════════════════════════════════════════════
 *  TOP — GLOBAL  (كل الأريناز مجموعة)
 * ═══════════════════════════════════════════════════
 *  %duel_top_wins_<rank>%               → اسم اللاعب رقم <rank> في الـ wins     (1-10)
 *  %duel_top_wins_<rank>_score%         → عدد wins تاعه
 *  %duel_top_losses_<rank>%             → اسم اللاعب رقم <rank> في الـ losses
 *  %duel_top_losses_<rank>_score%       → عدد losses تاعه
 *  %duel_top_points_<rank>%             → اسم اللاعب رقم <rank> في الـ points
 *  %duel_top_points_<rank>_score%       → عدد points تاعه
 *  %duel_top_streak_<rank>%             → اسم اللاعب رقم <rank> في الـ streak
 *  %duel_top_streak_<rank>_score%       → عدد streak تاعه
 *
 * ═══════════════════════════════════════════════════
 *  TOP — PER ARENA  (أرينا معينة)
 * ═══════════════════════════════════════════════════
 *  %duel_top_wins_<arena>_<rank>%       → اسم اللاعب رقم <rank> في أرينا <arena>
 *  %duel_top_wins_<arena>_<rank>_score% → عدد wins تاعه في الأرينا
 *  (نفس الصيغة لـ losses / points / streak)
 *
 *  مثال:
 *    %duel_top_wins_1%            → Steve        (global rank 1)
 *    %duel_top_wins_1_score%      → 42
 *    %duel_top_points_sword_1%    → Alex          (rank 1 in arena "sword")
 *    %duel_top_streak_sword_3_score% → 7
 */
public class DuelPlaceholders extends PlaceholderExpansion {

    private final DuelPlugin plugin;

    public DuelPlaceholders(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "duel"; }
    @Override public @NotNull String getAuthor()     { return "STARK NETWORK"; }
    @Override public @NotNull String getVersion()    { return plugin.getDescription().getVersion(); }
    @Override public boolean persist()               { return true; }
    @Override public boolean canRegister()           { return true; }

    // ─────────────────────────────────────────────────────────────────────────
    //  Main handler
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {

        DuelManager  dm = plugin.getDuelManager();
        QueueManager qm = plugin.getQueueManager();
        StatsManager sm = plugin.getStatsManager();

        String lower = params.toLowerCase();

        // ── General ───────────────────────────────────────────────────────────
        if (lower.equals("active")) return String.valueOf(dm.getAllActiveSessions().size());
        if (lower.equals("queued")) return String.valueOf(qm.getTotalQueued());

        // ── Party team colour (for TAB / nametag plugins) ─────────────────────
        // %duel_team_color% → "&9" (Blue) / "&c" (Red) while in a party team match, else ""
        // %duel_team%       → "Blue" / "Red" while in a party team match, else ""
        if (lower.equals("team_color") || lower.equals("team")) {
            if (player == null) return "";
            com.duel.models.PartyDuelSession ps = plugin.getPartyDuelManager().getSession(player);
            if (ps == null || ps.isFFA() || ps.getState() == com.duel.models.PartyDuelSession.State.ENDED) return "";
            int t = ps.getTeamOf(player);
            if (t == 1) return lower.equals("team") ? "Blue" : "&9";
            if (t == 2) return lower.equals("team") ? "Red"  : "&c";
            return "";
        }

        // ── Personal stats ────────────────────────────────────────────────────
        // %duel_wins_me%   → total wins for the requesting player (across all arenas)
        // %duel_points_me% → total points for the requesting player (across all arenas)
        if (lower.equals("wins_me") || lower.equals("points_me")) {
            if (player == null) return "0";
            StatsManager.PlayerStats stats = sm.getPlayerStats(player.getUniqueId());
            if (stats == null) return "0";
            return lower.equals("wins_me")
                    ? String.valueOf(stats.wins())
                    : String.valueOf(stats.points());
        }

        // ── Country / flag ───────────────────────────────────────────────────
        // %duel_country%  → "EG", "US", "XX" (unknown) or "" if player is null
        // %duel_flag%     → the flag emoji codepoint sequence for that country
        //                   (needs a resource pack to actually render as an image
        //                    in most Minecraft clients)
        if (lower.equals("country")) {
            if (player == null) return "";
            String code = plugin.getCountryManager().getCountryCode(player.getUniqueId());
            return code != null ? code : "..."; // lookup still in progress
        }
        if (lower.equals("flag")) {
            if (player == null) return "";
            String code = plugin.getCountryManager().getCountryCode(player.getUniqueId());
            if (code == null || code.equals("XX")) return "";
            return com.duel.managers.CountryManager.toFlagChar(code);
        }

        // ── Top placeholders ─────────────────────────────────────────────────
        // Format options:
        //   top_<type>_<rank>               → global name
        //   top_<type>_<rank>_score         → global score
        //   top_<type>_<arena>_<rank>       → per-arena name
        //   top_<type>_<arena>_<rank>_score → per-arena score

        if (!lower.startsWith("top_")) return null;

        // Remove "top_" prefix → e.g. "wins_1" / "wins_1_score" / "wins_sword_1" / "wins_sword_1_score"
        String rest = lower.substring(4); // after "top_"

        // Detect type (wins / losses / points / streak)
        TopType type = null;
        String  afterType = null;

        for (TopType t : TopType.values()) {
            String tName = t.name().toLowerCase(); // wins / losses / streak / points
            if (rest.startsWith(tName + "_")) {
                type      = t;
                afterType = rest.substring(tName.length() + 1); // strip "wins_"
                break;
            }
        }

        if (type == null || afterType == null || afterType.isEmpty()) return null;

        // afterType is now one of:
        //   "<rank>"              → global name
        //   "<rank>_score"        → global score
        //   "<arena>_<rank>"      → per-arena name
        //   "<arena>_<rank>_score"→ per-arena score

        // Try global first: afterType starts with a digit
        if (Character.isDigit(afterType.charAt(0))) {
            boolean wantScore = afterType.endsWith("_score");
            String  rankStr   = wantScore ? afterType.substring(0, afterType.length() - 6) : afterType;
            // strip trailing underscore if present
            if (rankStr.endsWith("_")) rankStr = rankStr.substring(0, rankStr.length() - 1);
            int rank = parseRank(rankStr);
            if (rank < 0) return null;

            List<PlayerStats> top = sm.getTopGlobal(type);
            return getValue(top, rank, wantScore, type);
        }

        // Per-arena: afterType = "<arena>_<rank>" or "<arena>_<rank>_score"
        boolean wantScore = afterType.endsWith("_score");
        String  withoutScore = wantScore ? afterType.substring(0, afterType.length() - 6) : afterType;
        if (withoutScore.endsWith("_")) withoutScore = withoutScore.substring(0, withoutScore.length() - 1);

        // Last segment after final "_" should be the rank number
        int lastUnderscore = withoutScore.lastIndexOf('_');
        if (lastUnderscore < 0) return null;

        String arenaId = withoutScore.substring(0, lastUnderscore);
        String rankStr = withoutScore.substring(lastUnderscore + 1);

        if (arenaId.isEmpty() || !Character.isDigit(rankStr.charAt(0))) return null;

        int rank = parseRank(rankStr);
        if (rank < 0) return null;

        List<PlayerStats> top = sm.getTop10(arenaId, type);
        return getValue(top, rank, wantScore, type);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────────────

    /** Parse rank string (1-10) → 0-based index, or -1 if invalid */
    private int parseRank(String s) {
        try {
            int r = Integer.parseInt(s.trim());
            return (r >= 1 && r <= 10) ? r - 1 : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Extract name or score from the list at index, return "--" if out of bounds */
    private String getValue(List<PlayerStats> list, int index, boolean wantScore, TopType type) {
        if (list == null || index >= list.size()) return "--";
        PlayerStats ps = list.get(index);

        if (!wantScore) return ps.name();

        return String.valueOf(switch (type) {
            case WINS   -> ps.wins();
            case LOSSES -> ps.losses();
            case STREAK -> ps.bestStreak();
            case POINTS -> ps.points();
        });
    }
}
