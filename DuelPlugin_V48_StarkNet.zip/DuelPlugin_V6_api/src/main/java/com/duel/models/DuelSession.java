package com.duel.models;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class DuelSession {

    public enum State { COUNTDOWN, FIGHTING, ENDED }

    private final UUID sessionId = UUID.randomUUID();
    private final Player player1;
    private final Player player2;
    private final Arena arena;
    private final String copiedWorldName;

    private State state = State.COUNTDOWN;
    private long startTime = System.currentTimeMillis();
    private Player winner;
    private org.bukkit.scoreboard.Scoreboard tabScoreboard = null;
    private org.bukkit.scheduler.BukkitTask pingTask = null;
    private org.bukkit.scheduler.BukkitTask countdownTask = null;
    private Player loser;
    private long countdownStartMs = System.currentTimeMillis();

    // تتبع البلوكات المبنية أثناء المباراة — Location → UUID اللاعب اللي بناها
    private final java.util.Map<Location, UUID> placedBlocks = new java.util.HashMap<>();

    // إسبون كل لاعب عند بداية المباراة (للتحقق من حد الارتفاع)
    private final java.util.Map<UUID, Location> playerSpawns = new java.util.HashMap<>();

    public void setPlayerSpawn(Player player, Location loc) {
        playerSpawns.put(player.getUniqueId(), loc.clone());
    }

    public Location getPlayerSpawn(Player player) {
        return playerSpawns.get(player.getUniqueId());
    }

    public void trackPlacedBlock(Location loc, Player placer) {
        placedBlocks.put(loc.getBlock().getLocation(), placer.getUniqueId());
    }

    public boolean isBlockPlacedByPlayer(Location loc, Player player) {
        UUID placer = placedBlocks.get(loc.getBlock().getLocation());
        return placer != null && placer.equals(player.getUniqueId());
    }

    public boolean isBlockPlacedByOpponent(Location loc, Player player) {
        UUID placer = placedBlocks.get(loc.getBlock().getLocation());
        if (placer == null) return false;
        return !placer.equals(player.getUniqueId());
    }

    public boolean isPlacedBlock(Location loc) {
        return placedBlocks.containsKey(loc.getBlock().getLocation());
    }

    public void untrackBlock(Location loc) {
        placedBlocks.remove(loc.getBlock().getLocation());
    }

    public DuelSession(Player p1, Player p2, Arena arena, String copiedWorldName) {
        this.player1 = p1;
        this.player2 = p2;
        this.arena = arena;
        this.copiedWorldName = copiedWorldName;
    }

    public UUID getSessionId()         { return sessionId; }
    public Player getPlayer1()         { return player1; }
    public Player getPlayer2()         { return player2; }
    public org.bukkit.scoreboard.Scoreboard getTabScoreboard() { return tabScoreboard; }
    public void setTabScoreboard(org.bukkit.scoreboard.Scoreboard sb) { this.tabScoreboard = sb; }
    public org.bukkit.scheduler.BukkitTask getPingTask() { return pingTask; }
    public void setPingTask(org.bukkit.scheduler.BukkitTask t) { this.pingTask = t; }
    public org.bukkit.scheduler.BukkitTask getCountdownTask() { return countdownTask; }
    public void setCountdownTask(org.bukkit.scheduler.BukkitTask t) { this.countdownTask = t; }
    public Arena getArena()            { return arena; }
    public String getCopiedWorldName() { return copiedWorldName; }
    public State getState()            { return state; }
    public void setState(State state)  { this.state = state; }
    public Player getWinner()          { return winner; }
    public Player getLoser()           { return loser; }

    public void setWinner(Player winner) {
        this.winner = winner;
        this.loser = winner == player1 ? player2 : player1;
    }

    public boolean hasPlayer(Player p) {
        return player1.equals(p) || player2.equals(p);
    }

    public long getCountdownStartMs() { return countdownStartMs; }
    public void markCountdownStart() { this.countdownStartMs = System.currentTimeMillis(); }

    public long getStartTime() { return startTime; }
    public void markStarted() { this.startTime = System.currentTimeMillis(); }

    public Player getOpponent(Player p) {
        return player1.equals(p) ? player2 : player1;
    }
}
